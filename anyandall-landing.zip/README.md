# Any & All – Midlertidig landingsside

Static site uden build (Tailwind via CDN) så den kan lægges direkte på GitHub Pages.

## Hurtig deploy (web-GUI)
1) Opret et nyt repository på GitHub, fx `anyandall-site` (Public).
2) Upload filerne `index.html` og `favicon.svg` (drag & drop i GitHub).
3) Gå til **Settings → Pages** og sæt:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main` / root ( `/` )
4) Når Pages er aktivt, udgives sitet på `https://<brugernavn>.github.io/anyandall-site/`.

## Custom domain
- Tilføj dit domæne under **Settings → Pages → Custom domain**.
- Opret en `CNAME` DNS-record for `www.anyandall.dk` → `<brugernavn>.github.io`.
- (Valgfrit) Læg en `CNAME`-fil i repo med indholdet `www.anyandall.dk`.

## Ændre kontaktinfo
Søg i `index.html` efter `hello@anyandall.dk` og `+45 71 99 00 00` og udskift.
